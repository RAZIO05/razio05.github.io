"""Live smoke test against a running ShipAI backend (expects http://127.0.0.1:8000).

Run:  python tests/smoke_test.py
Exit code 0 = all passed.
"""
import sys
import time

import requests

BASE = "http://127.0.0.1:8000"
EMAIL = f"smoke-{int(time.time())}@shipai.dev"
PWD = "supersecret123"

passed = failed = 0


def check(name, cond, detail=""):
    global passed, failed
    if cond:
        passed += 1
        print(f"✅ {name}")
    else:
        failed += 1
        print(f"❌ {name} — {detail[:160]}")


r = requests.post(f"{BASE}/auth/register", json={"email": EMAIL, "password": PWD})
check("register -> 201", r.status_code == 201, r.text)

r = requests.post(f"{BASE}/auth/register", json={"email": EMAIL, "password": PWD})
check("duplicate register -> 400", r.status_code == 400, r.text)

r = requests.post(f"{BASE}/auth/register", json={"email": "x@shipai.dev", "password": "short"})
check("weak password -> 422 (pydantic min_length)", r.status_code == 422, r.text)

r = requests.post(f"{BASE}/auth/login", json={"email": EMAIL, "password": PWD})
check("login -> 200 + access_token", r.status_code == 200 and "access_token" in r.json(), r.text)
token = r.json().get("access_token", "")

r = requests.post(f"{BASE}/auth/login", json={"email": EMAIL, "password": "wrongpass123"})
check("wrong password -> 400", r.status_code == 400, r.text)

r = requests.post(f"{BASE}/api/v1/process-ai", json={"prompt": "test"})
check("process-ai without token -> 401", r.status_code == 401, r.text)

r = requests.post(
    f"{BASE}/api/v1/process-ai",
    json={"prompt": "Analyze AI Micro-SaaS market in 2026.", "context": "US and Gulf."},
    headers={"Authorization": f"Bearer {token}"},
)
ok_real = r.status_code == 200 and {"status", "summary", "key_points", "action_items"} <= set(r.json())
ok_placeholder = r.status_code == 500 and "AI Engine Error" in r.text
check(
    "process-ai with token -> 200 structured JSON from Gemini",
    ok_real,
    r.text,
)

print(f"\nRESULT: {passed} passed, {failed} failed")
sys.exit(1 if failed else 0)
