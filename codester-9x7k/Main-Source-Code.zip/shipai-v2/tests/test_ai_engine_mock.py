"""Unit tests for ShipAI v2.0 (Gemini Engine + 5 Vertical Presets + SaaS Credit Billing).

Run:  python tests/test_ai_engine_mock.py
"""
import json
import sys
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from fastapi import HTTPException
from app import ai_engine
from app.schemas import AIPromptRequest
from app.presets import MICRO_SAAS_PRESETS, get_preset
from app.monetization import (
    ensure_user_wallet,
    consume_user_credit,
    verify_and_activate_license,
)


def test_process_ai_agent_task_parses_structured_json():
    fake_reply = {
        "status": "success",
        "summary": "AI Micro-SaaS has strong revenue potential in 2026.",
        "key_points": [
            "Vertical niches lower customer acquisition cost",
            "Structured Gemini output removes parsing glue code",
        ],
        "action_items": [
            "Pick one niche and validate demand this week",
            "Ship a landing page with the ShipAI sales copy",
        ],
    }
    captured = {}

    class FakeModels:
        def generate_content(self, model, contents, config):
            captured["model"] = model
            captured["contents"] = contents
            captured["config"] = config
            return SimpleNamespace(text=json.dumps(fake_reply))

    fake_client = SimpleNamespace(models=FakeModels())

    with patch.object(ai_engine, "client", fake_client):
        result = ai_engine.process_ai_agent_task(
            AIPromptRequest(
                prompt="Analyze the market potential of AI Micro-SaaS in 2026.",
                context="Focus on US and Gulf markets.",
                preset_id="saas_validator",
            )
        )

    assert result.status == "success"
    assert result.summary == fake_reply["summary"]
    assert result.preset_used == "saas_validator"
    assert captured["config"]["response_mime_type"] == "application/json"
    assert "Y Combinator" in captured["config"]["system_instruction"]
    print("✅ mock engine + vertical preset test passed ->", result.preset_used)


def test_presets_and_monetization_engine():
    assert len(MICRO_SAAS_PRESETS) >= 6
    assert get_preset("contract_auditor")["badge"] == "LegalTech SaaS"

    email = "founder@shipai.dev"
    wallet = ensure_user_wallet(email)
    initial_credits = wallet["credits_remaining"]
    assert initial_credits == 10
    assert wallet["plan_tier"] == "free"

    consume_user_credit(email, cost=3)
    assert ensure_user_wallet(email)["credits_remaining"] == 7

    # Exhaust remaining 7 credits and verify 402 Payment Required on next call
    consume_user_credit(email, cost=7)
    try:
        consume_user_credit(email, cost=1)
        raise AssertionError("Expected HTTP 402 Payment Required")
    except HTTPException as exc:
        assert exc.status_code == 402

    # Activate Pro License and verify +500 credits
    upgraded = verify_and_activate_license(email, "SHIPAI-PRO-2026")
    assert upgraded["plan_tier"] == "pro"
    assert upgraded["credits_remaining"] == 500
    print("✅ SaaS credit quota + 402 guard + license upgrade test passed")


if __name__ == "__main__":
    test_process_ai_agent_task_parses_structured_json()
    test_presets_and_monetization_engine()
    print("ALL MOCK TESTS PASSED")
