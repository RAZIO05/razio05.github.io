import streamlit as st
import requests
from app.presets import MICRO_SAAS_PRESETS

st.set_page_config(page_title="ShipAI v2.0 Commercial SaaS Dashboard", layout="centered")
st.title("⚡ ShipAI v2.0 — Commercial AI Micro-SaaS Engine")
st.caption("FastAPI + Google Gemini Structured JSON + SaaS Credit Billing + 5 Ready-to-Sell Vertical Presets")

st.markdown("---")

api_url = st.sidebar.text_input("FastAPI Base URL", "http://127.0.0.1:8000")
token = st.sidebar.text_input("JWT Bearer Token", type="password")

if token:
    st.sidebar.markdown("### 💳 SaaS Credit Wallet")
    try:
        wallet_res = requests.get(
            f"{api_url}/api/v1/billing/status",
            headers={"Authorization": f"Bearer {token}"},
            timeout=5,
        )
        if wallet_res.status_code == 200:
            w = wallet_res.json()
            st.sidebar.metric("Credits Remaining", w["credits_remaining"])
            st.sidebar.info(f"Plan Tier: **{w['plan_tier'].upper()}** | Runs: **{w['total_generations']}**")
    except Exception:
        pass

    with st.sidebar.expander("🔑 Activate Gumroad / Pro License"):
        lic_key = st.text_input("License Key", placeholder="SHIPAI-PRO-2026")
        if st.button("Activate License"):
            res = requests.post(
                f"{api_url}/api/v1/billing/activate-license",
                json={"license_key": lic_key},
                headers={"Authorization": f"Bearer {token}"},
            )
            if res.status_code == 200:
                st.success(f"Upgraded to {res.json()['plan_tier'].upper()}! Credits: {res.json()['credits_remaining']}")
            else:
                st.error(res.text)

st.subheader("1️⃣ Select Vertical Micro-SaaS Template")
preset_options = {p["id"]: f"{p['name']} ({p['badge']})" for p in MICRO_SAAS_PRESETS.values()}
selected_preset_id = st.selectbox(
    "Choose a built-in SaaS vertical:",
    options=list(preset_options.keys()),
    format_func=lambda k: preset_options[k],
)
active_preset = MICRO_SAAS_PRESETS[selected_preset_id]

st.subheader("2️⃣ Run Structured AI Task")
prompt_input = st.text_area("Enter User Prompt:", active_preset["default_prompt"], height=110)
context_input = st.text_input("Context (Optional):", active_preset["default_context"])

if st.button("🚀 Process via ShipAI v2.0 Engine"):
    if not token:
        st.error("Please provide a valid JWT Token in the sidebar.")
    else:
        headers = {"Authorization": f"Bearer {token}"}
        payload = {
            "prompt": prompt_input,
            "context": context_input,
            "preset_id": selected_preset_id,
        }

        with st.spinner(f"Running {active_preset['name']} via Gemini AI Engine..."):
            res = requests.post(f"{api_url}/api/v1/process-ai", json=payload, headers=headers)
            if res.status_code == 200:
                data = res.json()
                st.success(
                    f"Task Processed! (Preset: {data.get('preset_used', selected_preset_id)} | "
                    f"Plan: {str(data.get('plan_tier', 'free')).upper()} | "
                    f"Credits Left: {data.get('credits_remaining', 'N/A')})"
                )
                st.write(f"**Status:** {data['status']}")
                st.write(f"**Summary:** {data['summary']}")

                st.markdown("**Key Points:**")
                for point in data["key_points"]:
                    st.markdown(f"- {point}")

                st.markdown("**Action Items:**")
                for item in data["action_items"]:
                    st.markdown(f"- {item}")
            else:
                st.error(f"Error {res.status_code}: {res.text}")
