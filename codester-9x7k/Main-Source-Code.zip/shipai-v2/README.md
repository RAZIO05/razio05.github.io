# ⚡ ShipAI — Micro-SaaS & AI Agent Engine Boilerplate

Production-ready **FastAPI + Gemini AI + Streamlit** boilerplate for shipping AI
Micro-SaaS products fast. Includes JWT authentication, Pydantic v2 schemas, a
structured Gemini AI engine wrapper, and a ready-to-use Streamlit dashboard.

## 🚀 5-Minute Setup Guide

### 1. Clone & install dependencies (60s)

```bash
cd shipai-backend
python -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate
pip install -r requirements.txt
```

### 2. Configure environment (30s)

```bash
cp .env.example .env
```

Edit `.env` and set:

| Variable | Description |
|---|---|
| `SECRET_KEY` | A long random string for signing JWTs (change in production!) |
| `GEMINI_API_KEY` | Your Google Gemini API key ([get one at aistudio.google.com](https://aistudio.google.com)) |

### 3. Launch the FastAPI backend (10s)

```bash
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

Interactive API docs (Swagger UI) are now live at `http://127.0.0.1:8000/docs`.

### 4. Launch the Streamlit dashboard (10s)

```bash
streamlit run dashboard.py
```

### 5. First request — full auth flow

```bash
# Register a user
curl -X POST http://127.0.0.1:8000/auth/register \
  -H "Content-Type: application/json" \
  -d '{"email":"demo@shipai.dev","password":"supersecret123"}'

# Login and copy the access_token
curl -X POST http://127.0.0.1:8000/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"demo@shipai.dev","password":"supersecret123"}'

# Run the AI engine with the token
curl -X POST http://127.0.0.1:8000/api/v1/process-ai \
  -H "Authorization: Bearer <YOUR_ACCESS_TOKEN>" \
  -H "Content-Type: application/json" \
  -d '{"prompt":"Analyze the market potential of AI Micro-SaaS in 2026.","context":"Focus on US and Gulf markets."}'
```

## 📁 Project Structure

```
shipai-backend/
├── app/
│   ├── __init__.py
│   ├── main.py          # FastAPI application & routes
│   ├── config.py        # Central settings loader
│   ├── auth.py          # JWT auth: hashing, tokens, guards
│   ├── schemas.py       # Pydantic v2 request/response models
│   └── ai_engine.py     # Gemini structured-output wrapper
├── dashboard.py         # Streamlit frontend (Phase 2)
├── .env.example
├── requirements.txt
└── README.md
```

## 🔌 API Endpoints

| Method | Path | Auth | Description |
|---|---|---|---|
| POST | `/auth/register` | — | Register a new user (bcrypt-hashed password) |
| POST | `/auth/login` | — | Obtain a JWT access token |
| POST | `/api/v1/process-ai` | Bearer JWT | Run a prompt through the Gemini engine, get structured JSON |

## ⚠️ Production Notes

- Replace the in-memory `fake_users_db` with a real database (PostgreSQL + SQLAlchemy recommended).
- Set `allow_origins` in CORS to your actual frontend domain instead of `*`.
- Rotate `SECRET_KEY` and never commit `.env` to version control.

## 📜 License

Commercial License — build unlimited personal or commercial projects.
Reselling the raw boilerplate itself is not permitted.
