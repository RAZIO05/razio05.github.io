# ShipAI — Production Deployment Playbook (Docker, Railway, Render & Cloud Run)

This guide is included in the **Agency & Enterprise Edition** to deploy ShipAI to production in under 10 minutes.

---

## 1. One-Command Docker Deployment (`docker-compose`)

ShipAI includes a multi-service `Dockerfile` and `docker-compose.yml` running both the **FastAPI Backend (port 8000)** and **Streamlit Executive Dashboard (port 8501)**.

```bash
cp .env.example .env
# Edit .env and set your real GEMINI_API_KEY and a strong SECRET_KEY
docker compose up --build -d
```

- **Backend API & Swagger Docs:** `http://localhost:8000/docs`
- **Streamlit Dashboard:** `http://localhost:8501`

---

## 2. Deploying to Render.com / Railway.app

1. Push your `shipai-backend` repository to GitHub (make sure `.env` is in `.gitignore`).
2. Create a new **Web Service** on Render or Railway connected to your repo.
3. Set the Start Command:
   ```bash
   uvicorn app.main:app --host 0.0.0.0 --port $PORT
   ```
4. Add Environment Variables in the dashboard:
   - `GEMINI_API_KEY` = your Google AI Studio API key
   - `SECRET_KEY` = generate via `openssl rand -hex 32`
   - `ALGORITHM` = `HS256`
   - `ACCESS_TOKEN_EXPIRE_MINUTES` = `60`

---

## 3. Production Hardening Checklist for Client Projects

- **Secret Key Rotation:** Always generate a unique 256-bit `SECRET_KEY` per client deployment (`openssl rand -hex 32`).
- **CORS Allowlist:** In `app/main.py`, replace `allow_origins=["*"]` with your client's production frontend domain (e.g. `["https://app.clientdomain.com"]`).
- **Persistent Database Upgrade:** Swap `fake_users_db` in `app/main.py` with SQLAlchemy / PostgreSQL or Supabase when scaling to multi-instance containers.
