"""ShipAI v2.0 — SaaS Credit Quota & Gumroad License Verification Engine.

Allows ShipAI buyers to immediately monetize their own AI Micro-SaaS:
- Tracks per-user credit balances & plan tiers ('free', 'pro', 'agency').
- Enforces 402 Payment Required when free credits are exhausted.
- Verifies Gumroad license keys via Gumroad's /v2/licenses/verify API
  (plus built-in offline/demo keys for instant local testing).
"""
import os
from typing import Dict, Any
import requests
from fastapi import HTTPException, status

DEFAULT_FREE_CREDITS = int(os.getenv("DEFAULT_FREE_CREDITS", "10"))
GUMROAD_PRODUCT_ID = os.getenv("GUMROAD_PRODUCT_ID", "")

# In-memory SaaS billing ledger (swap with PostgreSQL/Redis in production)
_user_billing_ledger: Dict[str, Dict[str, Any]] = {}

DEMO_LICENSE_KEYS = {
    "SHIPAI-PRO-2026": {"plan_tier": "pro", "credits_added": 500},
    "SHIPAI-AGENCY-2026": {"plan_tier": "agency", "credits_added": 999999},
}


def ensure_user_wallet(email: str) -> Dict[str, Any]:
    if email not in _user_billing_ledger:
        _user_billing_ledger[email] = {
            "email": email,
            "plan_tier": "free",
            "credits_remaining": DEFAULT_FREE_CREDITS,
            "total_generations": 0,
            "license_key": None,
        }
    return _user_billing_ledger[email]


def consume_user_credit(email: str, cost: int = 1) -> Dict[str, Any]:
    wallet = ensure_user_wallet(email)
    if wallet["plan_tier"] != "agency" and wallet["credits_remaining"] < cost:
        raise HTTPException(
            status_code=status.HTTP_402_PAYMENT_REQUIRED,
            detail=(
                "Insufficient AI credits. Please upgrade your plan or activate "
                "a license key at POST /api/v1/billing/activate-license."
            ),
        )
    if wallet["plan_tier"] != "agency":
        wallet["credits_remaining"] -= cost
    wallet["total_generations"] += 1
    return wallet


def verify_and_activate_license(email: str, license_key: str) -> Dict[str, Any]:
    clean_key = license_key.strip()
    wallet = ensure_user_wallet(email)

    # 1. Check built-in demo/offline keys for instant testing
    if clean_key in DEMO_LICENSE_KEYS:
        grant = DEMO_LICENSE_KEYS[clean_key]
        wallet["plan_tier"] = grant["plan_tier"]
        wallet["credits_remaining"] += grant["credits_added"]
        wallet["license_key"] = clean_key
        return wallet

    # 2. Verify live against Gumroad's License Verification API if configured
    if GUMROAD_PRODUCT_ID:
        try:
            resp = requests.post(
                "https://api.gumroad.com/v2/licenses/verify",
                data={
                    "product_id": GUMROAD_PRODUCT_ID,
                    "license_key": clean_key,
                    "increment_uses_count": "true",
                },
                timeout=10,
            )
            data = resp.json()
            if resp.status_code == 200 and data.get("success"):
                wallet["plan_tier"] = "pro"
                wallet["credits_remaining"] += 500
                wallet["license_key"] = clean_key
                return wallet
        except Exception as exc:
            raise HTTPException(
                status_code=status.HTTP_502_BAD_GATEWAY,
                detail=f"Gumroad license verification error: {exc}",
            )

    raise HTTPException(
        status_code=status.HTTP_400_BAD_REQUEST,
        detail="Invalid license key. For local testing, use 'SHIPAI-PRO-2026' or 'SHIPAI-AGENCY-2026'.",
    )
