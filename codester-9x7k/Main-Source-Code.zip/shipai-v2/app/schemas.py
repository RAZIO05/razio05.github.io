from pydantic import BaseModel, EmailStr, Field
from typing import Optional, List


class UserRegister(BaseModel):
    email: EmailStr
    password: str = Field(..., min_length=8, description="User password")


class UserLogin(BaseModel):
    email: EmailStr
    password: str


class Token(BaseModel):
    access_token: str
    token_type: str = "bearer"


class AIPromptRequest(BaseModel):
    prompt: str = Field(..., description="The input prompt for the AI model")
    context: Optional[str] = Field(None, description="Optional system context")
    preset_id: Optional[str] = Field(
        "general",
        description="Vertical Micro-SaaS preset ID (general, saas_validator, contract_auditor, code_security_reviewer, resume_ats_optimizer, seo_content_architect)",
    )


class AIStructuredResponse(BaseModel):
    status: str
    summary: str
    key_points: List[str]
    action_items: List[str]
    preset_used: Optional[str] = "general"
    credits_remaining: Optional[int] = None
    plan_tier: Optional[str] = None


class LicenseActivationRequest(BaseModel):
    license_key: str = Field(..., min_length=5, description="Gumroad or ShipAI SaaS License Key")


class BillingStatusResponse(BaseModel):
    email: str
    plan_tier: str
    credits_remaining: int
    total_generations: int
    license_key: Optional[str] = None
