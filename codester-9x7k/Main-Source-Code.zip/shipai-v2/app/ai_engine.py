import os
import json
from google import genai
from dotenv import load_dotenv
from app.schemas import AIPromptRequest, AIStructuredResponse
from app.presets import get_preset

load_dotenv()

client = genai.Client(api_key=os.getenv("GEMINI_API_KEY"))

# Note (2026): Google retired `gemini-2.5-flash` for new API keys (HTTP 404).
# Default to `gemini-3.5-flash` with fallback to `gemini-flash-lite-latest` on 503/404.
DEFAULT_MODELS = [
    os.getenv("GEMINI_MODEL", "gemini-3.5-flash"),
    "gemini-flash-lite-latest",
    "gemini-3.8-flash",
]


def process_ai_agent_task(payload: AIPromptRequest) -> AIStructuredResponse:
    preset = get_preset(getattr(payload, "preset_id", "general"))
    system_instruction = preset["system_instruction"]

    full_prompt = f"Context: {payload.context or 'N/A'}\nUser Input: {payload.prompt}"

    last_err = None
    response = None
    for model_name in DEFAULT_MODELS:
        try:
            response = client.models.generate_content(
                model=model_name,
                contents=full_prompt,
                config={
                    "response_mime_type": "application/json",
                    "system_instruction": system_instruction,
                },
            )
            break
        except Exception as err:
            last_err = err
            msg = str(err)
            if "404" in msg or "503" in msg or "UNAVAILABLE" in msg or "NOT_FOUND" in msg:
                continue
            raise

    if response is None:
        raise last_err

    parsed_json = json.loads(response.text)
    parsed_json.setdefault("preset_used", preset["id"])
    return AIStructuredResponse(**parsed_json)
