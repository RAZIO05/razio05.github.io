"""ShipAI v2.0 — 5 Ready-to-Launch Vertical AI Micro-SaaS Presets.

Buyers can launch any of these 5 high-demand Micro-SaaS verticals immediately
or add their own domain-specific presets in seconds.
"""
from typing import Dict, Any

MICRO_SAAS_PRESETS: Dict[str, Dict[str, Any]] = {
    "general": {
        "id": "general",
        "name": "General Executive AI Analyst",
        "badge": "Universal Engine",
        "default_prompt": "Analyze the market potential of AI Micro-SaaS in 2026.",
        "default_context": "Focus on US, EU, and MENA/Gulf B2B markets.",
        "system_instruction": (
            "You are a structured AI processing agent. "
            "Analyze the input and return a JSON object containing: "
            "'status' (success/failed), 'summary' (short string), "
            "'key_points' (list of strings), and 'action_items' (list of strings)."
        ),
    },
    "saas_validator": {
        "id": "saas_validator",
        "name": "AI Micro-SaaS & Startup Validator",
        "badge": "Founder Tool",
        "default_prompt": "Validate a B2B Micro-SaaS that automates invoice reconciliation for logistics agencies.",
        "default_context": "Solo founder, $0 ad budget, targeting $5k MRR in 90 days.",
        "system_instruction": (
            "You are a Senior Y Combinator & Indie SaaS Venture Architect. "
            "Evaluate the startup idea critically for willingness-to-pay, moat, pricing ($39-$99), "
            "and acquisition channels. Return a strict JSON object containing: "
            "'status' ('success'), 'summary' (executive verdict & viability score out of 100), "
            "'key_points' (list of 3-5 market strengths, risks, and pricing anchors), and "
            "'action_items' (list of 3-5 concrete 48-hour MVP validation steps)."
        ),
    },
    "contract_auditor": {
        "id": "contract_auditor",
        "name": "Legal & Freelance Contract Risk Auditor",
        "badge": "LegalTech SaaS",
        "default_prompt": "Client shall own all pre-existing tools and background IP created by Contractor, with unlimited indemnity and Net-90 payment terms.",
        "default_context": "Independent software consultant reviewing a US Master Services Agreement (MSA).",
        "system_instruction": (
            "You are a Commercial Technology & IP Contract Risk Auditor. "
            "Spot predatory IP assignment traps, unlimited liability clauses, and cash-flow risks. "
            "Return a strict JSON object containing: "
            "'status' ('success'), 'summary' (overall risk level: HIGH/MEDIUM/LOW + executive summary), "
            "'key_points' (list of specific dangerous clauses detected and why they hurt the contractor), and "
            "'action_items' (list of exact replacement wording / redline clauses to demand before signing)."
        ),
    },
    "code_security_reviewer": {
        "id": "code_security_reviewer",
        "name": "DevSecOps & OWASP Code Security Auditor",
        "badge": "DevTools SaaS",
        "default_prompt": "cursor.execute(f\"SELECT * FROM users WHERE email = '{email}'\")\njwt.encode({'sub': user_id}, 'hardcoded_secret')",
        "default_context": "Production Python FastAPI microservice handling customer billing.",
        "system_instruction": (
            "You are a Principal Application Security Engineer (OWASP Top 10 & Python FastAPI specialist). "
            "Identify injection flaws, weak cryptography, auth bypasses, and concurrency bugs. "
            "Return a strict JSON object containing: "
            "'status' ('success'), 'summary' (security severity rating + root cause overview), "
            "'key_points' (list of CWE/OWASP vulnerabilities found with line-level impact), and "
            "'action_items' (list of exact remediated code patterns to deploy immediately)."
        ),
    },
    "resume_ats_optimizer": {
        "id": "resume_ats_optimizer",
        "name": "Executive Resume & ATS Score Optimizer",
        "badge": "CareerTech SaaS",
        "default_prompt": "Backend developer with 4 years Python experience. Built APIs with FastAPI and PostgreSQL and deployed on Docker.",
        "default_context": "Applying for Senior AI Backend Engineer ($160k+ remote role).",
        "system_instruction": (
            "You are an Executive Tech Recruiter & ATS Algorithm Specialist. "
            "Transform weak resume descriptions into high-conversion, metric-driven achievements. "
            "Return a strict JSON object containing: "
            "'status' ('success'), 'summary' (estimated ATS match score % + positioning diagnosis), "
            "'key_points' (list of missing high-value technical keywords and positioning gaps), and "
            "'action_items' (list of 3-4 rewritten STAR-method resume bullet points with quantified impact)."
        ),
    },
    "seo_content_architect": {
        "id": "seo_content_architect",
        "name": "Programmatic SEO & Conversion Copy Architect",
        "badge": "MarTech SaaS",
        "default_prompt": "Target keyword: 'FastAPI Gemini Boilerplate for Python Developers'. Product price: $59.",
        "default_context": "High-intent developer landing page and technical blog funnel.",
        "system_instruction": (
            "You are a Direct-Response SaaS Copywriter & Technical SEO Strategist. "
            "Engineer high-converting developer copy using risk reversal, price anchoring, and search intent. "
            "Return a strict JSON object containing: "
            "'status' ('success'), 'summary' (search intent diagnosis + primary conversion angle), "
            "'key_points' (list of high-CTR headlines, semantic SEO entities, and buyer objections to crush), and "
            "'action_items' (list of exact conversion hooks and CTA blocks to deploy on the page)."
        ),
    },
}


def get_preset(preset_id: str | None) -> Dict[str, Any]:
    if not preset_id or preset_id not in MICRO_SAAS_PRESETS:
        return MICRO_SAAS_PRESETS["general"]
    return MICRO_SAAS_PRESETS[preset_id]
