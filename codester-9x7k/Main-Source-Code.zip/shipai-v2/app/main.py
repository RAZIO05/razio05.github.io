from fastapi import FastAPI, Depends, HTTPException, status
from fastapi.middleware.cors import CORSMiddleware
from app.schemas import (
    UserRegister,
    UserLogin,
    Token,
    AIPromptRequest,
    AIStructuredResponse,
    LicenseActivationRequest,
    BillingStatusResponse,
)
from app.auth import hash_password, verify_password, create_access_token, get_current_user
from app.ai_engine import process_ai_agent_task
from app.presets import MICRO_SAAS_PRESETS
from app.monetization import (
    ensure_user_wallet,
    consume_user_credit,
    verify_and_activate_license,
)

app = FastAPI(
    title="ShipAI v2.0 - Commercial Micro-SaaS Engine",
    description="Production-Ready FastAPI + Google Gemini AI Boilerplate with SaaS Credits, Gumroad License Verification & 5 Vertical Micro-SaaS Presets",
    version="2.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Simulated in-memory database for boilerplate demonstration
fake_users_db = {}


@app.get("/health")
def health_check():
    return {
        "status": "healthy",
        "version": "2.0.0",
        "presets_available": list(MICRO_SAAS_PRESETS.keys()),
    }


@app.post("/auth/register", status_code=status.HTTP_201_CREATED)
def register(user: UserRegister):
    if user.email in fake_users_db:
        raise HTTPException(status_code=400, detail="Email already registered")
    fake_users_db[user.email] = hash_password(user.password)
    wallet = ensure_user_wallet(user.email)
    return {
        "message": "User registered successfully",
        "plan_tier": wallet["plan_tier"],
        "credits_remaining": wallet["credits_remaining"],
    }


@app.post("/auth/login", response_model=Token)
def login(user: UserLogin):
    hashed_pwd = fake_users_db.get(user.email)
    if not hashed_pwd or not verify_password(user.password, hashed_pwd):
        raise HTTPException(status_code=400, detail="Invalid credentials")

    ensure_user_wallet(user.email)
    access_token = create_access_token(data={"sub": user.email})
    return {"access_token": access_token, "token_type": "bearer"}


@app.get("/api/v1/presets")
def list_micro_saas_presets():
    """Return all 5+ built-in vertical AI Micro-SaaS templates."""
    return {
        "count": len(MICRO_SAAS_PRESETS),
        "presets": [
            {
                "id": p["id"],
                "name": p["name"],
                "badge": p["badge"],
                "default_prompt": p["default_prompt"],
                "default_context": p["default_context"],
            }
            for p in MICRO_SAAS_PRESETS.values()
        ],
    }


@app.get("/api/v1/billing/status", response_model=BillingStatusResponse)
def get_billing_status(current_user: str = Depends(get_current_user)):
    """Inspect current user's SaaS credit balance and active plan tier."""
    return ensure_user_wallet(current_user)


@app.post("/api/v1/billing/activate-license", response_model=BillingStatusResponse)
def activate_license(
    payload: LicenseActivationRequest,
    current_user: str = Depends(get_current_user),
):
    """Upgrade a user's SaaS plan and credit balance using a Gumroad or ShipAI license key."""
    return verify_and_activate_license(current_user, payload.license_key)


@app.post("/api/v1/process-ai", response_model=AIStructuredResponse)
def execute_ai_task(payload: AIPromptRequest, current_user: str = Depends(get_current_user)):
    # 1. Verify & deduct SaaS credit before invoking Gemini
    wallet = consume_user_credit(current_user, cost=1)
    try:
        result = process_ai_agent_task(payload)
        result.credits_remaining = wallet["credits_remaining"]
        result.plan_tier = wallet["plan_tier"]
        return result
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"AI Engine Error: {str(e)}")
