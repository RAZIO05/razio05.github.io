# ShipAI — Unlimited Agency & Enterprise Commercial License

**Tier:** Agency / Enterprise Edition ($499)  
**Version:** 1.0.0 (2026 Edition)

## Grant of License
This Agency & Enterprise License grants the purchaser ("Licensee") a perpetual, worldwide, non-exclusive, royalty-free right to:

1. **Unlimited Commercial SaaS Products:** Use the ShipAI codebase to build, launch, and monetize an unlimited number of Micro-SaaS applications and internal tools.
2. **Unlimited Client & White-Label Work:** Deliver customized applications built upon ShipAI to an unlimited number of paying clients, agencies, or enterprise customers under your own brand (White-Label).
3. **Team Seat Coverage:** Up to 25 developers within your organization or agency may access and modify the codebase for client or internal deployments.

## Restrictions
- Licensee may NOT redistribute, publish, or resell the raw ShipAI boilerplate itself as a competing starter kit, boilerplate, or template marketplace item.

## Warranty & Liability
THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED.
